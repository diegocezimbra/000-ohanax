export { Table, TableHead, TableBody, TableRow, TableHeader, TableCell } from './Table'
export type { TableProps, TableHeadProps, TableBodyProps, TableRowProps, TableHeaderProps, TableCellProps } from './Table'
