export { Text } from './Text'
export type { TextProps, TextVariant } from './Text'
